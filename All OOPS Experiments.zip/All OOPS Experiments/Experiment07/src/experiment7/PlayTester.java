package experiment7;

public class PlayTester
{
	 public static void main(String[] args) {
	     MusicPlayer player = new MusicPlayer();

	     player.play();
	     player.pause();
	     player.stop();
	 }
	}

