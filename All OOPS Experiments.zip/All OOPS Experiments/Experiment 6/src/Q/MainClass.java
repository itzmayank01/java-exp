package Q;

public class MainClass {
	 public static void main(String[] args) {
	     Logger logger = new Logger();

	     logger.logMessage("This is a test log message.");
	 }
	}
