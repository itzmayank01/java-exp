package Q;

final class Logger {

 void logMessage(String message) {
     System.out.println("Log: " + message);
 }
}


