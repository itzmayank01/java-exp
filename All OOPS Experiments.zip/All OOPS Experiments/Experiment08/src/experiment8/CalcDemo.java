package experiment8;

public class CalcDemo {
	public static void main ( String [] args) {
		   Calc rf = new Calc();
		   int one = rf.divide(15, 0);
		   System.out.println(one);
	   }
}
